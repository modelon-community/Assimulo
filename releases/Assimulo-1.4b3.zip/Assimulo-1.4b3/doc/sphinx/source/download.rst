

=============
Download
=============

Current version:

    - `Assimulo-1.4b3.zip <https://trac.jmodelica.org/assimulo/export/275/releases/Assimulo-1.4b3.zip>`_
   
See :doc:`installation` for instructions on setting up Assimulo. Christoph Gohlke have also created one-click windows installers for Assimulo which are available `here <http://www.lfd.uci.edu/~gohlke/pythonlibs/#assimulo>`_ .


To retrieve the latest version using a subversion software use::

    svn checkout https://svn.jmodelica.org/assimulo/tags/Assimulo-1.4b2

To retrieve the latest (develop) version using a subversion software use::

    svn checkout https://svn.jmodelica.org/assimulo/trunk


.. warning::

    The latest (develop) version may not function properly.


Old versions:
    
    - `Assimulo-1.4b2.zip <https://trac.jmodelica.org/assimulo/export/275/releases/Assimulo-1.4b2.zip>`_
    - `Assimulo-1.4b1.zip <https://trac.jmodelica.org/assimulo/export/275/releases/Assimulo-1.4b1.zip>`_
    - `Assimulo-1.3b1.zip <https://trac.jmodelica.org/assimulo/export/275/releases/Assimulo-1.3b1.zip>`_
    - `Assimulo-1.2b1.zip <https://trac.jmodelica.org/assimulo/export/275/releases/Assimulo-1.2b1.zip>`_
    - `Assimulo-1.1b1.zip <https://trac.jmodelica.org/assimulo/export/275/releases/Assimulo-1.1b1.zip>`_
    - `Assimulo-1.0b2.zip <https://trac.jmodelica.org/assimulo/export/275/releases/Assimulo-1.0b2.zip>`_

.. Assimulo documentation master file, created by
   sphinx-quickstart on Thu Apr 15 16:33:46 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
   
====================================
Documentation contents
====================================

 
Contents
==============


.. toctree::
   :maxdepth: 2
   
   usage

.. toctree::
   :maxdepth: 3
   
   examples
   jmodelica
   download
   installation
   code
   changelog
   tutorial


.. toctree::
   :glob:
   :hidden:

   solver*


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

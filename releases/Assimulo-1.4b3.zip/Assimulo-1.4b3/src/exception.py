
class AssimuloException(Exception):
    pass 

class TerminateSimulation(AssimuloException):
    pass

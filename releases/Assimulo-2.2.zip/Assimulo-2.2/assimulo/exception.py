
class AssimuloException(Exception):
    pass 

class TerminateSimulation(AssimuloException):
    pass

class DiscardValue(AssimuloException):
    pass

class Explicit_ODE_Exception(AssimuloException):
    pass
    
class ODE_Exception(AssimuloException):
    pass

class Implicit_ODE_Exception(AssimuloException):
    pass    
    
class Rodas_Exception(AssimuloException):
    pass
    
class Dopri5_Exception(AssimuloException):
    pass
    
class GLIMDA_Exception(AssimuloException):
    pass

class ODEPACK_Exception(AssimuloException):
    pass

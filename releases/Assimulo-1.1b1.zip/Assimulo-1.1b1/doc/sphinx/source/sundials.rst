


====================
Sundials Wrapper
====================


.. literalinclude:: sundials_core.pyx
   :language: python


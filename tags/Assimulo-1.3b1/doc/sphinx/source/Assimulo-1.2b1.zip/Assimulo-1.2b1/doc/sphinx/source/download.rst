

=============
Download
=============

Current version:

    - :download:`Assimulo-1.2b1.zip <Assimulo-1.2b1.zip>`
   
See :doc:`installation` for instructions on setting up Assimulo.


To retrieve the latest version using a subversion software use::

    svn checkout https://svn.jmodelica.org/assimulo/tags/Assimulo-1.2b1

To retrieve the latest (develop) version using a subversion software use::

    svn checkout https://svn.jmodelica.org/assimulo/trunk


.. warning::

    The latest (develop) version may not function properly.


Old versions:
    
    - :download:`Assimulo-1.1b1.zip <Assimulo-1.1b1.zip>`
    - :download:`Assimulo-1.0b2.zip <Assimulo-1.0b2.zip>`

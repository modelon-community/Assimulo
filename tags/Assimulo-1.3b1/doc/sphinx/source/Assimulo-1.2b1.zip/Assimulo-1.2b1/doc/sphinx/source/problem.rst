 
Problem Class
=============================

.. autoclass:: assimulo.problem.Problem
   :members:
 

Explicit Problem
-----------------------
 
.. autoclass:: assimulo.problem.Explicit_Problem
    :members: 


  
Implicit Problem
-----------------------
 
.. autoclass:: assimulo.problem.Implicit_Problem
    :members:


===============
Usage
===============

Explicit Solvers
----------------

.. toctree::
   :maxdepth: 1
   :glob:
   
   solver_exp*


Implicit Solvers
----------------

.. toctree::
   :maxdepth: 1
   :glob:
   
   solver_imp*


==========
Changelog
==========

--- Assimulo-1.2b1 ---
    * Implemented basic support for calculating sensitivities using CVodes.
    * Changed from using CVode to CVodes.
    * Added 'echo' methods used for viewing the current solver settings.
    * Fixed a bug with the reset method not resetting the statistics.
    * Fixed a bug which was exposed when overwriting the switches.
    * Added a custom error method in CVode and IDA.
    * Fixed a segmentation fault discovered on Mac when IDAS was used.
    * Renamed the test modules to lowercase.
    * Renamed the setup script to setup_from_binary (used when a pre-compiled
      binary is distributed)

--- Assimulo-1.1b1 ---
    * Fixed a bug with re-init resulting in resetting the options.
    * Moved the result handling to the problem class.
    * Renamed the event function to state_events.
    * Improved the information displayed after a simulation (mainly for IDA and CVode).
    * Added support for step events (completed_step).
    * Added support for time events.
    * Implemented basic support for calculating sensitivities using IDAS.
    * Renamed the modules to correspond to Python standard (all lowercase).
      Classes starts with a capital letter.
    * Implemented Radau5 for both explicit and implicit problems.
    * Wrapped an interpolate method from Sundials (IDAGetDky, CVodeGetDky)
    * Changed from using IDA to IDAS
    * Changed assimulo.problem.Problem_Name to problem_name.
    * Changed assimulo.ODE.problemname to problem_name.
    * Fixed a bug when printing information when used FixedPoint.
    * Changed algvar to be more type independent.
    * Added **kwargs to the plotting functionality.

--- Assimulo-1.0b2 ---
    * Added an option to mask which variables that is to be plotted.
    * Added a .simulate function for use when simulating instead of
      __call__. Although __call__ can still be used.
    * Added a plotting functionality for plotting the step-size used
      together with the order used when the simulation have been
      run with one-step mode in either CVode or IDA.
    * Added so that when using IDA or CVode in one-step mode, the 
      current order and the last order are stored.
    * Added option to specify initial step-size in CVode.
    * Added support to switch between using the user defined Jacobian
      in CVode or not.
    * Added support to switch between using the user defined Jacobian
      in IDA or not.
    * Added support for user-defined Jacobians when using CVode.
    * Added support for user-defined Jacobians when using IDA.

--- Assimulo-1.0b1 ---
    * The rough first version.



